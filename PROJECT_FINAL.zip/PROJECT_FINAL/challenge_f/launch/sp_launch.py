import os
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
from launch import LaunchDescription
def generate_launch_description():
    config = os.path.join(get_package_share_directory('challenge_f'),'config','params.yaml')
    setpoint_node = Node(
        package = 'challenge_f',
        executable = 'setpoint',
        output = 'screen',
        parameters = [config]
    )
    rqt_plot_node = Node(
        package = 'rqt_plot',
        executable = 'rqt_plot',
        parameters = [{'args': '/setpoint/micro_ros_esp32/signal'}]
    )
    ld = LaunchDescription([setpoint_node, rqt_plot_node])
    return ld
