import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np
from scipy import signal

class Node_SG(Node):
    def __init__(self):
        super().__init__('setpoint')
        self.declare_parameters(
            namespace='',
            parameters=[
                ('signal_type', rclpy.Parameter.Type.INTEGER),
                ('constant.value', rclpy.Parameter.Type.DOUBLE),
                ('sine.amplitude', rclpy.Parameter.Type.DOUBLE),
                ('sine.frequency', rclpy.Parameter.Type.DOUBLE), 
                ('sine.offset', rclpy.Parameter.Type.DOUBLE),
                ('square.amplitude', rclpy.Parameter.Type.DOUBLE),
                ('square.frequency', rclpy.Parameter.Type.DOUBLE), 
                ('square.offset', rclpy.Parameter.Type.DOUBLE),
                ('sawtooth.amplitude', rclpy.Parameter.Type.DOUBLE),
                ('sawtooth.frequency', rclpy.Parameter.Type.DOUBLE), 
                ('sawtooth.offset', rclpy.Parameter.Type.DOUBLE),
                ('triangle.amplitude', rclpy.Parameter.Type.DOUBLE),
                ('triangle.frequency', rclpy.Parameter.Type.DOUBLE), 
                ('triangle.offset', rclpy.Parameter.Type.DOUBLE),
                ('damped.amplitude', rclpy.Parameter.Type.DOUBLE),
                ('damped.frequency', rclpy.Parameter.Type.DOUBLE), 
                ('damped.offset', rclpy.Parameter.Type.DOUBLE),
            ]
        )
        self.t = 0
        self.timer_period_1 = 0.02
        self.pub_1 = self.create_publisher(Float32, "control/signal", 10)
        self.timer_1 = self.create_timer(self.timer_period_1, self.callback_1)
        self.get_logger().info('Setpoint node initialized')
        self.msg_1 = Float32()

    def callback_1(self):
        self.signal_type = self.get_parameter('signal_type').get_parameter_value().integer_value
        if (self.signal_type == 0):
            self.v = self.get_parameter('constant.value').get_parameter_value().double_value
            self.msg_1.data = self.v
        elif (self.signal_type == 1):
            self.a = self.get_parameter('sine.amplitude').get_parameter_value().double_value
            self.f = self.get_parameter('sine.frequency').get_parameter_value().double_value
            self.o = self.get_parameter('sine.offset').get_parameter_value().double_value
            self.msg_1.data = self.a * np.sin(2 * np.pi * self.f * self.t) + self.o
        elif (self.signal_type == 2):
            self.a = self.get_parameter('square.amplitude').get_parameter_value().double_value
            self.f = self.get_parameter('square.frequency').get_parameter_value().double_value
            self.o = self.get_parameter('square.offset').get_parameter_value().double_value
            self.msg_1.data = self.a * signal.square(2 * np.pi * self.f * self.t) + self.o
        elif (self.signal_type == 3):
            self.a = self.get_parameter('sawtooth.amplitude').get_parameter_value().double_value
            self.f = self.get_parameter('sawtooth.frequency').get_parameter_value().double_value
            self.o = self.get_parameter('sawtooth.offset').get_parameter_value().double_value
            self.msg_1.data = (2 * self.a) / np.pi * np.arctan(np.tan(np.pi * self.f * self.t)) + self.o
        self.pub_1.publish(self.msg_1)
        self.t = self.t + self.timer_period_1

def main(args = None):
    rclpy.init(args = args)
    n_sg = Node_SG()
    rclpy.spin(n_sg)
    n_sg.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
